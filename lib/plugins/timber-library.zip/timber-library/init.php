<?php

use Timber\Timber;

$timber = new Timber();
Timber::$dirname = 'views';